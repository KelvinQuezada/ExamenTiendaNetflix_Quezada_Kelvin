package netflix.mundo_KQ;

import netflix.interfaces_KQ.IVisualizableKQ;


public class Pelicula_KQ implements IVisualizableKQ{
	//ATRIBUTO
	
	private String tituloKQ;
	private String generoKQ; 
	private String creadorKQ; 
	private int a�oKQ; 
	private String duracionKQ;
	private boolean vistoKQ;
		
	public Pelicula_KQ(String tituloKQ, String generoKQ, String creadorKQ, int a�oKQ, String duracionKQ,
			boolean vistoKQ) {
		super();
		this.tituloKQ = tituloKQ;
		this.generoKQ = generoKQ;
		this.creadorKQ = creadorKQ;
		this.a�oKQ = a�oKQ;
		this.duracionKQ = duracionKQ;
		this.vistoKQ = vistoKQ;
	}

	//duracion inciialziada en falso
	
	public Pelicula_KQ() {
		
		this.tituloKQ = null;
		this.generoKQ = null;
		this.creadorKQ = null;
		this.a�oKQ = 0;
		this.duracionKQ = null;
		this.vistoKQ = false;
	}
	

	@Override
	public String toString() {
		return "Pelicula_KQ [tituloKQ=" + tituloKQ + ", generoKQ=" + generoKQ + ", creadorKQ=" + creadorKQ + ", a�oKQ="
				+ a�oKQ + ", duracionKQ=" + duracionKQ + ", vistoKQ=" + vistoKQ + "]";
	}

	public String getTitulo() {
		return tituloKQ;
	}

	public void setTitulo(String titulo) {
		this.tituloKQ = titulo;
	}

	public String getGenero() {
		return generoKQ;
	}

	public void setGenero(String genero) {
		this.generoKQ = genero;
	}

	public String getCreador() {
		return creadorKQ;
	}

	public void setCreador(String creador) {
		this.creadorKQ = creador;
	}

	public int getA�o() {
		return a�oKQ;
	}

	public void setA�o(int a�o) {
		this.a�oKQ = a�o;
	}

	public String getDuracion() {
		return duracionKQ;
	}

	public void setDuracion(String duracion) {
		this.duracionKQ = duracion;
	}

	public boolean isVisto() {
		return vistoKQ;
	}
	

	public void setVisto(boolean visto) {
		this.vistoKQ = visto;
	}

	public void esVisto() {
		// TODO Auto-generated method stub
		
	}

	public void tiempoVisto() {
		// TODO Auto-generated method stub
		
	}

	public void marcarVisto() {
		// TODO Auto-generated method stub
		
	}
	

}
