package netflix.mundo_KQ;

import java.util.ArrayList;

public class Principal_NetflixKQ {
	
	private ArrayList <Pelicula_KQ> pelicula_KQ= new ArrayList<Pelicula_KQ>();
	private ArrayList <Serie_KQ> serie_KQ = new ArrayList <Serie_KQ>();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Creacion de objetos");
		Pelicula_KQ pelicula_KQ[] = {new Pelicula_KQ("Hombre Arana", "Masculino",  "Jhon Peter", 2021, "3:12:00", true),
				new Pelicula_KQ("Spiderman", "Femenino",  "Jhon Peter", 2018, "3:12:00", true )};
		Serie_KQ serie_KQ[] = {new Serie_KQ("30 pecados", 3, "Femenino", "3:00:00"), new Serie_KQ ("Soledad", 1, "Masculino", "2:10:20")};
		System.out.println("Imprimir por pantalla");
		System.out.println(pelicula_KQ);
		System.out.println(serie_KQ);
	}
	
	
}