package netflix.mundo_KQ;

public abstract class classNetflix_KQ {
	
	protected String tituloKQ; 
	 protected int numeroTemporadasKQ; 
	 protected boolean vistoKQ; 
	 protected String generoKQ;
	 protected String duracionKQ;
	 
	public classNetflix_KQ(String tituloKQ, int numeroTemporadasKQ, 
			boolean vistoKQ, String generoKQ,String duracionKQ) {
		this.tituloKQ = tituloKQ;
		this.numeroTemporadasKQ = numeroTemporadasKQ;
		this.vistoKQ = vistoKQ;
		this.generoKQ = generoKQ;
		this.duracionKQ = duracionKQ;
	}
	public String getTituloKQ() {
		return tituloKQ;
	}
	public void setTituloKQ(String tituloKQ) {
		this.tituloKQ = tituloKQ;
	}
	public int getNumeroTemporadasKQ() {
		return numeroTemporadasKQ;
	}
	public void setNumeroTemporadasKQ(int numeroTemporadasKQ) {
		this.numeroTemporadasKQ = numeroTemporadasKQ;
	}
	public boolean isVistoKQ() {
		return vistoKQ;
	}
	public void setVistoKQ(boolean vistoKQ) {
		this.vistoKQ = vistoKQ;
	}
	public String getGeneroKQ() {
		return generoKQ;
	}
	public void setGeneroKQ(String generoKQ) {
		this.generoKQ = generoKQ;
	}
	public String getDuracionKQ() {
		return duracionKQ;
	}
	public void setDuracionKQ(String duracionKQ) {
		this.duracionKQ = duracionKQ;
	}
	 
}
