package netflix.mundo_KQ;

public class Serie_KQ {
	//ATRIBUTOS
	
	private String tituloKQ; 
	 private int numeroTemporadasKQ; 
	 private boolean vistoKQ; 
	 private String generoKQ;
	 private String duracionKQ;
	 //CONSTRUCTOR
	public Serie_KQ(String tituloKQ, int numeroTemporadasKQ, 
			String generoKQ, String duracionKQ) {
		this.tituloKQ = tituloKQ;
		this.numeroTemporadasKQ = numeroTemporadasKQ;
		this.generoKQ = generoKQ;
		this.duracionKQ = duracionKQ;
		this.vistoKQ=false;
		
	}
	public String getTituloKQ() {
		return tituloKQ;
	}
	public void setTituloKQ(String tituloKQ) {
		this.tituloKQ = tituloKQ;
	}
	public int getNumeroTemporadasKQ() {
		return numeroTemporadasKQ;
	}
	public void setNumeroTemporadasKQ(int numeroTemporadasKQ) {
		this.numeroTemporadasKQ = numeroTemporadasKQ;
	}
	public String getGeneroKQ() {
		return generoKQ;
	}
	public void setGeneroKQ(String generoKQ) {
		this.generoKQ = generoKQ;
	}
	public String getDuracionKQ() {
		return duracionKQ;
	}
	public void setDuracionKQ(String duracionKQ) {
		this.duracionKQ = duracionKQ;
	}
	@Override
	public String toString() {
		return "Serie_KQ [tituloKQ=" + tituloKQ + ", numeroTemporadasKQ=" + 
	numeroTemporadasKQ + ", vistoKQ=" + vistoKQ
				+ ", generoKQ=" + generoKQ + ", duracionKQ=" + duracionKQ + "]";
	}

}
