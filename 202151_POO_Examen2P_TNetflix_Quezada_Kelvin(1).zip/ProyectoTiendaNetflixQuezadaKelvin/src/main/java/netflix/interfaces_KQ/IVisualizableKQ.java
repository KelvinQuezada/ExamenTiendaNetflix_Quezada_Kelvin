package netflix.interfaces_KQ;

public interface IVisualizableKQ {
	public void marcarVisto(); // cambia el atributo de visto a true.
	public void esVisto(); // devulve el estado del atributo visto.
	public void tiempoVisto(); // devuelve el tiempo en minutos que se visualiz� el video.

}
